
checkVariableNames = function(join_dataset){
  #' checkVariableNames
  #' @description Checks that join dataset variable names meet the critera for a stata dataset. The critera is: characters must be equal or less than 32, only letters, numbers and underscore (no punctuation), and must start with letter or underscore.
  #' @param join_dataset The dataset that is intended to be joined to a stata dataset.
  #' @return if the variable names are valid. Prints a message describing problem and specific variable that is the problem if invalid.

  message('\n -----------------------------------')
  message('Running: checkVariableNames')

  names<-colnames(join_dataset)
  pass = TRUE
  message = list()
  for (name in names){
    #check the number of characters
    if (nchar(name)>32){
      pass = FALSE
      message = append(message, paste0("Variable ", name, " contains too many characters. Only 32 characters allowed in Stata."))
    }

    #check that only letters, numbers and underscore are included
    if(grepl("[^[:alnum:]_]", name)){
      pass = FALSE
      message = append(message, paste0("Variable ", name, " contains invalid characters. Only letters, numbers, and underscore are allowed in Stata"))
    }

    #check that the first character is not a number
    if(grepl("^\\d", name)){
      pass = FALSE
      message = append(message, paste0("Variable ", name, " starts with a number. In Stata variables must start with a letter or an underscore"))
    }
  }

  if (!pass){
    message("Error:")
    message(message)
    file.copy(paste0('log/', logNm), paste0(output_location, 'report.log'))
    stop("Variable names don't adhere to stata rules. Please adjust input data and start again")
    return(F)
    
  }

  return(pass)
}

checkVariableNames_duplicates = function(dataset1, dataset2){
  #' checkVariableNames_duplicates
  #' @description Checks that the two datasets don’t contain any duplicate variable names.
  #' @param dataset1 a dataframe to join
  #' @param dataset2 a dataframe to join
  #' @return True if none of the variable names are duplicates, otherwise false if there is overlap

  message('\n -----------------------------------')
  message('Running: checkVariableNames_duplicates')

  names1<-colnames(dataset1)
  names2<-colnames(dataset2)

  if (length(intersect(names1, names2))>0){

    message(paste0("duplicate variables - the variable(/s) ", toString(intersect(names1,names2)),
                 " is in both datasets"))
    stop("Survey data and Join data contain duplicate variable names")
    file.copy(paste0('log/', logNm), paste0(output_location, 'report.log'))
    return(FALSE)

  }

  else{
    print('no duplicates found')
    return(TRUE)
  }

}


checkPostcodeColumn<- function(dataset, postcode_column_name){
  #' checkPostcodeColumn
  #' @description Checks that the join column (postcodes) contain valid values.
  #' @param dataset the dataset
  #' @param postcode_column_name the postcode column (add as an object not a string)
  #' @return True if all the values are valid
  message('\n -----------------------------------')
  message('Running: checkPostcodeColumn')

  p = enquo(postcode_column_name)

  e = dataset %>%
  filter(!grepl("^[[:digit:]]{4}$", !!p)) %>%
   select(!!p)

  if (e %>% count() %>% pull() == dataset %>% count() %>% pull()){
   stop("postcode column values not valid. Post code must have 4 numeric digits")
  }
  else if (e %>% count() %>% pull() > 0){
   warning(paste("Some values in postcode column are invalid. see values:\n", toString(e %>% pull())))
  }
  else{
   return(TRUE)
  }

}


#### ---- What is the outcome of this function? ---- ##
checkJoinRuleList = function(join_rule_list){
  #' checkJoinRuleList
  #' @description checks join rule list against global variables defining years of spatial and survey datasets. Throws warning if datasets will not be included. To sit within the joinDataDefined function.
  #' @param join_rule_list a named list defining the join rules for years in the intersected dataset

  message('\n -----------------------------------')
  message('Running: checkJoinRuleList')

  if(!(length(setdiff(joinData_year,join_rule_list))==0)){
    warning(paste("The join data year/s", toString(setdiff(joinData_year,join_rule_list)),
                  "are not in the join rules and won't be included in the intersected dataset"))
  }
  if(!(length(setdiff(survey_year,names(join_rule_list)))==0)){
    warning(paste("The survey data year/s", toString(setdiff(survey_year,names(join_rule_list))),
                  "are not in the join rules and won't have any data joined to them"))
  }

}






