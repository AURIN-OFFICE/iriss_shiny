
joinDataSimple = function(survey_dataset, join_dataset, output_path, by_data_year = FALSE) {
  #' joinDataSimple
  #' @description Joins datasets on postcode with option to also join by matching the added ‘data-year’ column
  #' @param survey_dataset a stata dataframe
  #' @param join_dataset a dataset
  #' @param output_path the location and name of the integrated dta file
  #' @param by_data_year logical variable indicating if data should also be joined by matching year variable
  #' @return a joined dataset.

  message('\n -----------------------------------')
  message('Running: joinDataSimple')

  if (!by_data_year){
    join = c("poa_name_2016" = "postcode")
  } else {
    join = c("poa_name_2016" = "postcode", "data_year_survey" = "data_year_join")
  }

  output <- survey_dataset %>%
    left_join(join_dataset, by = join)

  write_stata(output, paste0(output_path))
  print(paste0('The file was stored correctly: ', output_path))

  return(TRUE)

}


joinDataDefined = function(survey_dataset, join_dataset, output_path, join_rules){
  #' joinDataDefined
  #' @description Joins datasets on postcode and by a rule for years
  #' @param survey_dataset a stata dataframe
  #' @param join_dataset a dataset
  #' @param output_path the location and name of the integrated dta file
  #' @param join_rules a named list that links years between datasets that should be joined
  #' @return True
  message('\n -----------------------------------')
  message('Running: joinDataDefined')

  checkJoinRuleList(join_rules)

  output <- survey_dataset %>%
    mutate(join_year = join_rules[data_year_survey]) %>%
    left_join(join_dataset, by = c("poa_name_2016" = "postcode", "join_year" = "data_year_join"))

  write_stata(output, paste0(output_path))
  print(paste0('The file was stored correctly: ', output_path))
  return(TRUE)
}
