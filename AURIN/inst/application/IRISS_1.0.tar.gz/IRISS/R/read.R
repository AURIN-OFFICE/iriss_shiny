readSurveyDataset <- function(folder,data_name, year) {
  #' readSurveyDataset
  #' @description Reads one or more stata datasets, and combines them if necessary. If more than one dataset is read and combined, a column 'data_year' is added with the datasets year that row belongs to.
  #' @param folder The path to the folder where the stata datasets are store
  #' @param data_name The name of the dataset
  #' @param  year Either a string containing a single year, or a list of strings containing multiple years
  #' @return A dataframe with stata labels intact.

  out <- tryCatch({
    message('\n -----------------------------------')
    message('Running: readSurveyDataset')


    if (is.list(year)){

      data <- data.frame()
      data_labels <- data.frame()

      for (y in year){
        data_path <- paste0(folder,'/',data_name,'_',y,".dta")
        data_part<- haven::read_stata(data_path) %>%
          mutate(data_year_survey = y)

        data_part = as.data.frame(data_part)
        #### ----- Get stata labels ------ ####
        labels_stata <- haven::as_factor(data_part, levels="labels")
        ##### ----- Comparison between datasets ---- ####
        comparison = summary(comparedf(data, data_part))
        ##### ----- Identify different variables ----- ###
        dif_classes = comparison$vars.nc.table
        #### ------ If is not differences: join ----- ###
        if (dim(dif_classes)[1]==0) {
          data <- bind_rows(data,data_part)
          data_labels <- bind_rows(data_labels,labels_stata)

        #### ------- In case that have a differences ----- ####
        #### ------ We need to transformate the class of both datasets ----- #####
        } else {
          #### ---- In case that have different variables ----- ######
          for (j in c(1:dim(dif_classes)[1])) {
            clases_targe = class(data[,dif_classes[j,'pos.x']])
            #### ---- Change teh class of the data part ------ #####
            data_part[,dif_classes[j,'pos.y']] = as(data_part[,dif_classes[j,'pos.y']],class(tail(clases_targe,1)))
            #### ---- Change the class of the main category ---- ###
            data[,dif_classes[j,'pos.x']] = as(data_part[,data[j,'pos.x']],class(tail(clases_targe,1)))

          }
          #### ---- After transfromate the classes: Join the data ---- ###
          data <- bind_rows(data,data_part)
          data_labels <- bind_rows(data_labels,labels_stata)

        }



      }



    } else {

      data_path <- paste0(folder,'/',data_name,'_',year,".dta")
      data<- haven::read_stata(data_path)
    }

    print(paste0(data_name, ' year(s) ', toString(year), ' was read correctly'))


    return(data)

  }, error = function(e){
    message("Error reading file:")
    message(e)
    return(NA)
  })
  return(out)
}

readSpatialDataset <- function(folder,data_name, year) {
  #' readSpatialDataset
  #' @description Reads one or more gml datasets, and combines them if necessary. If more than one dataset is read and combined, a column 'data_year' is added with the datasets year that row belongs to.
  #' @param folder The path to the folder where the spatial datasets are store
  #' @param data_name The name of the dataset
  #' @param year Either a string containing a single year, or a list of strings containing multiple years
  #' @return A dataframe with geometries removed

  out <- tryCatch({
    message('\n -----------------------------------')
    message(paste0('Running: readSpatialDataset:',data_name))


    if (is.list(year)){

      data <- data.frame()
      for (y in year){
        data_path <- paste0(folder,'/',data_name,'_',y,".gml")
        data_part<- read_sf(data_path)%>%
          st_drop_geometry() %>%
          mutate("postcode" = as.character(postcode),
                 "data_year_join" = y)
        data <- bind_rows(data, data_part)
      }

    } else {

      data_path <- paste0(folder,'/',data_name,'_',year,".gml")
      data<- read_sf(data_path)%>%
        st_drop_geometry() %>%
        mutate("postcode" = as.character(postcode))
    }

    print(paste0(data_name,' year(s) ', toString(year), ' was read correctly'))
    return(data)

  }, error = function(e){
    message("Error reading file:")
    message(e)
    return(NA)
  })
  return(out)
}

