LogDataInputs = function(){
  #' Log data inputs
  #' @description this function takes inputs (stored as global variables) and records them as a message
  #' for the log file
  #' @return True
  
  output_path <- paste0(output_location, output_name)
  
  message('\n -----------------------------------')
  message(paste0("Input survey dataset(s): ", 
                 toString(paste0(survey_name, "_", survey_year)),
                 "\n Input spatial dataset(s): ",
                 toString(paste0(joinData_name, "_", joinData_year)),
                 "\n Output joined dataset: ",
                 output_path,
                 "\n Join rules: \n \t -matching postcodes",
                 if_else(simpleJoin, 
                         if_else(simpleJoin_joinYear,
                                 "\n \t -matching dataset year(s)",
                                 ""),
                         paste("\n \t -matching years according to the following rules: \n \t \t ",
                               paste(names(join_rule_list), join_rule_list, sep = "=", collapse = "\n \t \t  ")))))
}
