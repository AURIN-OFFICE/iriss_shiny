
addPOA <- function (POA,path) {
  #' addPOA
  #' @description Only used during testing - randomly assigns postcodes to data to assist in testing joins on spatial identifiers.
  #' @param POA The postcode dataset.
  #' @param path The location of the stata dataset
  #' @return True if the file is storage correctly

  ### ---- Read file ----- ####
  message('\n -----------------------------------')
  message('Running: addPOA')

  AuSSA<- read_stata(path)
  #### ----- -------- ####
  ln <- count(AuSSA) %>%
    pull()

  k<-  POA %>%
    sample_n(ln) %>%
    select(poa_name_2016) %>%
    st_drop_geometry() %>%
    bind_cols(AuSSA)

  #### ---- Write file ----- ####
  write_stata(k,path)
  print('Adding postcode: O.K')
  return(TRUE)

}


